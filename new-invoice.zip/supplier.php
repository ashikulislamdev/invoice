<?php

	$views = "supplier";
	include('template.php');

?>