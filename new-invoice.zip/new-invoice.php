<?php 
    $views = 'new-invoice';
    include('template.php');
?>