<?php 
    $views = 'invoice';
    include('template.php');
?>