<?php

	$views = "customer";
	include('template.php');

?>