<?php

	$views = "profile";
	include('template.php');

?>