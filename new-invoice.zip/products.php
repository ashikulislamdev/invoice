<?php

	$views = "products";
	include('template.php');

?>