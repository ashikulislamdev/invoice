<?php

	$views = "loan";
	include('template.php');

?>