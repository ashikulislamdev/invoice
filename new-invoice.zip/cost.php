<?php

	$views = "cost";
	include('template.php');

?>