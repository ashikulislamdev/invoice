<?php 
    $views = 'invoice-details';
    include('template.php');
?>